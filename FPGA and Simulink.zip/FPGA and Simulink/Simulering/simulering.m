    Ts = 0.01;
    gear = 90;
    
    % Tilt
    % Motor
    Ktilt = 0.01542;
    Rtilt = 7.2719;
    Ltilt = 3.366*10^(-3);
    Jmtilt = 5.9992*10^(-7);
    Bmtilt = 2.5643*10^(-6);

    % System
    Jtilt = 0.01682;
    Btilt = 0.0105354*5;
    
    
    
    % Pan
    Kpan = 0.01701;
    Rpan = 5.21716;
    Lpan = 3.364*10^(-3);
    Jmpan = 9.69686*10^(-7);
    Bmpan = 1.4146*10^(-6);
    
    %system
    Jpan = 0.0878;
    Bpan = 0.094421*2.5;% mangler
